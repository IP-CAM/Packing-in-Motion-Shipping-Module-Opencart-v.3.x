<?php
/**
 *  Avatec Paczkawruchu Integration
 *  Copyright (c) 2020 Grzegorz Miskiewicz
 *  All Rights Reserved
 */

$_ = [
    'text_title' => 'Paczka w Ruchu',
    'text_description' => 'Paczkawruchu',

    'button_close' => 'Zamknij',
    'button_select' => 'Wybierz'
];
